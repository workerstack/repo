# Deploy

How we deploy: `make deploy`.
