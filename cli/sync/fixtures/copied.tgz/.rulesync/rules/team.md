---
root: false
targets: ["*"]
globs: ["**/*"]
---
Team rule: run `make lint` before every push.
