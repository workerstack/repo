/**
 * Where repo state lives for a hook or script call (roadmap D1, D2).
 *
 *   root      `.tmp/repo` scratch: the main checkout, so subdirs and worktrees share one
 *   checkout  tracked files (lessons, `.rulesync/scripts`): the checkout the agent works in
 *   cwd       paths the agent typed and child-process cwds: the hook's cwd, else the sent workspace
 *
 * A repo install is the nearest dir holding INSTALL_MARKER, up to the git top level, so a
 * repo install in a subpackage keeps its own root. All three share the `realpath.native` spelling, so a
 * symlink, a junction or a Windows 8.3 short name compares equal to the path git prints. Node builtins only.
 */
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { HookInput } from "./hook-input.ts";

export const INSTALL_MARKER = ".rulesync/scripts/workspace-root.ts";

export interface GitFacts {
  top: string;
  gitDir: string;
  commonDir: string;
}

/** Root, checkout and cwd spellings for one hook or script call. */
export interface Roots {
  root: string;
  checkout: string;
  cwd: string;
}

interface RootsContext {
  git: (dir: string) => GitFacts | null;
  p: typeof path;
  exists: (abs: string) => boolean;
  realpath: (abs: string, p?: typeof path) => string;
}

const revParseMemo = new Map<string, GitFacts | null>();

/** `{ top, gitDir, commonDir }` for `dir`, or null outside git. Memoized for this process only. */
export function gitRevParse(dir: string): GitFacts | null {
  if (revParseMemo.has(dir)) return revParseMemo.get(dir) ?? null;
  let facts: GitFacts | null = null;
  try {
    const out = execFileSync(
      "git",
      ["-C", dir, "rev-parse", "--path-format=absolute", "--show-toplevel", "--git-dir", "--git-common-dir"],
      { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] },
    );
    const [top, gitDir, commonDir] = out.split(/\r?\n/);
    if (top && gitDir && commonDir) facts = { top, gitDir, commonDir };
  } catch {
    facts = null;
  }
  revParseMemo.set(dir, facts);
  return facts;
}

/**
 * `abs` with its nearest existing ancestor in the `realpath.native` spelling. A relative path, a non-string, or a
 * path for a foreign `p` (a `path.win32` test on Linux) comes back unchanged.
 */
export function canonicalPath(abs: string, p: typeof path = path): string {
  if (p !== path || typeof abs !== "string" || !path.isAbsolute(abs)) return abs;
  let dir = abs;
  while (!fs.existsSync(dir)) {
    const up = path.dirname(dir);
    if (up === dir) return abs;
    dir = up;
  }
  try {
    return path.join(fs.realpathSync.native(dir), path.relative(dir, abs));
  } catch {
    return abs;
  }
}

/** A path an agent typed, resolved against the roots' cwd, in the roots' spelling. */
export function resolveTyped(roots: { cwd: string }, raw: string, p: typeof path = path): string {
  return canonicalPath(p.resolve(roots.cwd, raw), p);
}

function firstString(...values: unknown[]): string {
  for (const v of values) if (typeof v === "string" && v.trim()) return v.trim();
  return "";
}

function asDir(value: string): string {
  return value.startsWith("file:") ? fileURLToPath(value) : value;
}

function within(p: typeof path, top: string, dir: string): boolean {
  const rel = p.relative(top, dir);
  return !rel.startsWith("..") && !p.isAbsolute(rel);
}

/** Nearest dir from `dir` up to the git top level that holds the repo marker, else that top level. */
function checkoutIn(dir: string, facts: GitFacts | null, { p, exists, realpath }: RootsContext): string {
  if (!facts) return dir;
  const top = realpath(p.resolve(facts.top));
  if (!within(p, top, dir)) return top;
  for (let d = dir; ; d = p.dirname(d)) {
    if (exists(p.join(d, INSTALL_MARKER))) return d;
    if (d === top) return top;
  }
}

function rootsFor(start: string, ctx: RootsContext): { checkout: string; root: string } {
  const facts = ctx.git(start);
  const checkout = checkoutIn(start, facts, ctx);
  if (!facts) return { checkout, root: checkout };
  const { p } = ctx;
  const gitDir = ctx.realpath(p.resolve(facts.gitDir));
  const commonDir = ctx.realpath(p.resolve(facts.commonDir));
  if (gitDir === commonDir || p.basename(commonDir) !== ".git") return { checkout, root: checkout };
  const main = p.dirname(commonDir);
  return { checkout, root: p.join(main, p.relative(ctx.realpath(p.resolve(facts.top)), checkout)) };
}

/** Resolves roots from a hook input; reads workspaceRoot, workspace_root, workspacePaths, cwd and toolCall.args.Cwd. */
export function resolveRoots(
  input: HookInput | null = {},
  {
    env = process.env,
    cwd = process.cwd(),
    git = gitRevParse,
    p = path,
    exists = fs.existsSync,
    realpath = canonicalPath,
  }: Partial<RootsContext> & { env?: NodeJS.ProcessEnv; cwd?: string } = {},
): Roots {
  const data: HookInput = input && typeof input === "object" ? input : {};
  const args = data.toolCall?.args ?? {};
  const ctx: RootsContext = { git, p, exists, realpath };
  const paths = Array.isArray(data.workspacePaths) ? data.workspacePaths : [];
  const given = firstString(data.workspaceRoot, data.workspace_root, paths[0]);
  // A workspace the harness sent beats the hook process cwd as where the agent works.
  const hookCwd = realpath(p.resolve(cwd, asDir(firstString(data.cwd, args.Cwd, given) || ".")));
  const candidate = firstString(given, env.GROK_WORKSPACE_ROOT, env.CLAUDE_PROJECT_DIR);
  const start = candidate ? realpath(p.resolve(cwd, asDir(candidate))) : hookCwd;
  return {
    root: rootsFor(start, ctx).root,
    checkout: rootsFor(hookCwd, ctx).checkout,
    cwd: hookCwd,
  };
}
