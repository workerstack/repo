---
name: x
paths: ["workerstack.config.ts"]
hits: 1
last-hit: 2026-11-01
evidence: ["incident 1"]
---

# Cache keys need the tenant id

Two tenants shared one cache entry.

## Mistake
A cache key built from the route alone served one tenant's page to another.

## Fix
Build every cache key from the tenant id and the route.
