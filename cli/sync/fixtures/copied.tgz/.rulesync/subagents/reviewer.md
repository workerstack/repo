---
name: reviewer
description: "Reviews a diff against the team rule."
tier: scout
exec: true
claudecode:
  model: haiku
  effort: low
---
Review the diff and report findings only.
