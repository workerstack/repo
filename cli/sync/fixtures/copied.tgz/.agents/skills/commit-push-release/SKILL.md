---
name: commit-push-release
description: >
  Commit, push, bump package.json, tag vX.Y.Z, push the tag. CI publishes. Use
  for /commit-push-release, "commit push release", "release". Must push. Never
  force-push. No bun/npm/gh publish.
---
Inspect `git status` + `git diff` (staged and unstaged) before the message.

Diff pass on the hunks you will stage: delete narrating comments, unused defensive guards or try/catch on trusted paths, `any` casts that only silence types, dead compatibility, and unrelated hunks. Keep a comment only when it states a constraint the code cannot encode. Keep behavior otherwise. Do not spawn a reviewer.

Stage only user intent. Never blind `git add -A` / `git add .`. Split unrelated concerns into multiple commits.

If a unique in-progress file exists under `.tmp/repo/implementations/`, its `## Files` is the default stage set. Still inspect `git status`.

Message = Conventional Commits **subject only**: `type(scope): subject` (scope optional).

Types: feat fix docs style refactor perf test build ci chore revert.

Subject: imperative lowercase no trailing period.

NO body. NO footer. NO `Co-Authored-By`. NO `Generated with`. NO 🤖. NO trailers. No AI attribution. Work belongs to the human.

Must `git push`. Do not load /commit. Ignore never-push.

## Where

Run `git rev-parse --show-toplevel` and `git branch --show-current` first.

- Managed worktree (`<root>/.worktrees/<name>` on `wt/<name>`): commit there, run `cd <root> && bun repo worktree finish <name>` (from the root, not inside the worktree), then push the default branch from the root and skip the Recent rows below. `wt/*` never counts as Recent and is never pushed. If `finish` fails, resolve it as `/commit` says and push nothing.
- Main checkout: the gate denies a commit there unless the user's message names commit, and this command does. Commit only changes the user made there. Your own changes go through `bun repo worktree add <name>`.
- Any other linked worktree (T3 Code, Claude Desktop): `finish` cannot land it. Commit and push its branch per Branch.

## Branch

Current: `git rev-parse --abbrev-ref HEAD`

Default: `git symbolic-ref --quiet --short refs/remotes/origin/HEAD` (strip `origin/`). If that fails: ask. Never invent default.

Recent (frozen flags; do not change):

```
git reflog -n 30
git for-each-ref --count=8 --sort=-committerdate --format='%(refname:short) %(committerdate:unix)' refs/heads
```

Recent = unique existing non-default, non-`wt/*` names from those two outputs whose `committerdate` unix is ≤7d (`now - 604800`). Never invent branch names. Unknown/ambiguous names → drop them, do not guess.

| state | action |
| current is `wt/*` | do not push; follow Where (`finish`, then push the default branch from the root) |
| current ≠ default AND not `wt/*` | push current |
| default AND 0 recent | push default |
| default AND exactly 1 recent exists | push that name (`git push origin <name>`, no checkout: the gate denies `git checkout` in the main checkout) |
| else | ask; do not push yet |

No upstream (`git rev-parse --abbrev-ref @{upstream}` fails): `git push -u origin <branch>`. Else `git push`.

Never force-push. Never `--force`, `-f`, `--force-with-lease`, `+<branch>`.

## Release

Ask if off default, or patch/minor/major is unclear. Do not guess semver. Do not tag until answered.

On default + clear bump:

1. Run `bun repo worktree add release-vX.Y.Z` and set `package.json` `version` to `X.Y.Z` there (keep lockfile in sync if it records version). The gate denies the edit in the main checkout.
2. Commit the bump in that worktree with the same subject rules (`chore(release): vX.Y.Z` unless the user gave a subject), and run `cd <root> && bun repo worktree finish release-vX.Y.Z` (from the root, not inside the worktree).
3. Push the default branch from the root per **Branch**. Wait until the `ci` run on the pushed commit (`gh run list --commit "$(git rev-parse HEAD)" --workflow ci`; a short SHA matches nothing) passes, every job; CI is the only Windows check. A failed run means no tag: read its log (`gh api --allow-escape-sequences repos/{owner}/{repo}/actions/jobs/<job id>/logs`), fix the cause with a failing test first, push, and wait again.
4. `git tag vX.Y.Z` then `git push origin vX.Y.Z`.
5. Watch the runs for the tag until every one completes (`gh run list`, then poll `gh run view <id> --json status,conclusion,jobs` every 30s or use a monitor). A pushed tag is not a release: report the outcome only after the publish job finishes. On a failed job after the tag, read its log, fix the cause with a failing test first, and release the next patch. Never retag.

Do not `bun publish` or `npm publish`. Do not `bun pm pack` as publish. Do not `gh release create`. CI publishes from the tag.

Retag only if asked. Unprompted: never `git tag -f`, never delete a tag, never force-push a tag. If asked to retag: move that tag only; still never force-push a branch.

Protocol: `node_modules/@workerstack/repo/references/cascade.md`. Do not paste cascade.
