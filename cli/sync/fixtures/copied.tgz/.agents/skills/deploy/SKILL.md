---
name: deploy
description: "Deploy the app with the team script."
---

# Deploy

Run `make deploy` and report the URL.
