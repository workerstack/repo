---
name: principle-type-system-discipline
description: >-
  Apply when designing types, reviewing a function signature, or writing code in
  any statically-typed language. Make illegal states unrepresentable, brand
  semantic primitives, parse external data at boundaries, exhaust variants,
  derive from authoritative schemas. Use for /principle-type-system-discipline.
---
# Type System Discipline

Make the compiler reject impossible states, mismatched primitives, and unhandled variants. Prefer defining errors and special cases out of existence over proliferating handlers. For TypeScript syntax, see `/typescript-best-practices`.

Slash `/principle-type-system-discipline` only. Not a session flag.

- **Brand semantic primitives.** `UserId` and `OrderId` are strings underneath but should not be interchangeable. Give each its own type, such as a branded intersection in TypeScript or a newtype elsewhere. Validate once at creation, trust the type downstream. If two arguments share a primitive type but mean different things, brand them.
- **External data is untyped until parsed.** RPC payloads, JSON, IPC messages, CLI args, config files, environment variables, database rows. Have a parse function at every boundary that turns unstructured input into the typed model. `/principle-boundary-discipline` says where to put validation.
- **Derive types from authoritative schemas.** When a protocol buffer, OpenAPI spec, GraphQL schema, database migration, design-token file, or another file owns a shape, derive from it instead of hand-rolling a parallel type. See `/principle-encode-lessons-in-structure`.
