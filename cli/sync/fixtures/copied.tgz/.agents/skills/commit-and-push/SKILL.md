---
name: commit-and-push
description: >
  Alias of commit-push (1-release stub). Use for /commit-and-push, "commit and
  push", "commit this and push". Must push. Prefer /commit-push.
---
Thin alias → `.agents/skills/commit-push/SKILL.md`. Must push. Do not load /commit.

Protocol: `node_modules/@workerstack/repo/references/cascade.md`. Do not paste cascade.
