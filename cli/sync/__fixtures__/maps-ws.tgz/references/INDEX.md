# Index

Essay-style INDEX must not appear as a catalog row.

Hand text above the refs stays.

<!-- repo:refs -->
<!-- /repo:refs -->

<!-- repo:stack -->
<!-- /repo:stack -->
