---
description: Nested beta ref
---
# Beta nested

Beta body.
